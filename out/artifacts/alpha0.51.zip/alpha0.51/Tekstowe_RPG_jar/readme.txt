�eby mo�na by�o wys�a� plik gmailem musia�em zmieni� rozszerzenie pliku.

�eby� m�g� sobie zagra� musisz z nazwy pliku Tekstowe RPG.jar.usunTo usunac poprostu ostania czesc zeby zosta�o 
Tekstowe RPG.jar

Jak nie pokazuja ci sie rozszerzenia tylko masz "Tekstowe RPG" to poszukaj na necie "pokazywanie rozszerzen plikow"

to tyle have fun